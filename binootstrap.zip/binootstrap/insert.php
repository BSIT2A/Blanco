
<!-- insertinf research and file code -->

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <h2 class="text-center mb-4">Submission Form</h2>
      <form action="#" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label for="author">Author:</label>
          <input type="text" class="form-control" id="author" name="author" required>
        </div>
        <div class="form-group">
          <label for="title">Title:</label>
          <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
          <label for="course">Course:</label>
          <input type="text" class="form-control" id="course" name="course" required>
        </div>
        <div class="form-group">
          <label for="abstract">Abstract:</label>
          <textarea class="form-control" id="abstract" name="abstract" rows="4" required></textarea>
        </div>
        <div class="form-group">
          <label for="file">Attach File:</label>
          <input type="file" class="form-control-file" id="file" name="file">
        </div>
        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
      </form>
    </div>
  </div>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    include_once 'conn/connection.php';
    
    // Get form data
    $author = $_POST['author'];
    $title = $_POST['title'];
    $course = $_POST['course'];
    $abstract = $_POST['abstract'];
    
    // Check if file is uploaded
    if(isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file_name = $_FILES['file']['name'];
        $file_tmp_name = $_FILES['file']['tmp_name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        
        $upload_dir = 'uploads/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Recursive directory creation
        }
        // Move uploaded file to desired directory
        $file_destination = 'uploads/' . $file_name;
        move_uploaded_file($file_tmp_name, $file_destination);
    } else {
        $file_destination = ''; // If no file uploaded
    }
    
    // Prepare and execute SQL statement to insert data into database
    $sql = "INSERT INTO articles (author, title, course, abstract, file_path) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $author, $title, $course, $abstract, $file_destination);
    
    if ($stmt->execute()) {
        echo "<script>alert('Data inserted successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
    
    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

   