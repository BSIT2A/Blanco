<?php
session_start();
include_once 'conn/connection.php'; // Include your database connection

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Determine which table to query based on the selected role
    $table = ($role == 'superadmin') ? 'superadmins' : 'admins';

    // Prepare SQL statement to fetch user data from database
    $sql = "SELECT id, username, password FROM $table WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute(); 
    $stmt->store_result();

    // Check if username exists
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $db_username, $db_password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $db_password)) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $id;
            $_SESSION['user_username'] = $db_username;

            // Redirect to appropriate dashboard based on role
            if ($role == 'superadmin') {
                header("Location: superadmin_dash.php");
            } else {
                header("Location: admin_dash.php");
            }
            exit();
        } else {
            // Password is incorrect
            echo "Incorrect password.";
        }
    } else {
        // Username doesn't exist
        echo "Username not found.";
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
}
?>
