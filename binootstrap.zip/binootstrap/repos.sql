-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2024 at 03:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `repos`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` enum('thesis_adviser','thesis_critic') NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `role`, `username`, `password`) VALUES
(1, 'admin1', 'thesis_adviser', 'admin1', '$2y$10$.ix6y2YPb85RTDeig7T3AOHgZkyKm452MqYyTxI1UYzVuIxMsBT0.'),
(2, 'try', 'thesis_critic', 'critic1', '$2y$10$rtplNH9apSd2bJRj1p2EfOmXKcQ6SJkhraYAT6uqZrY0z6DEUumQe'),
(3, 'adviser1', 'thesis_adviser', 'adviser1', '$2y$10$C8H2xSmUTKas0lSSiZaVAefoluI.kBXiY2BRHlbv1guRmnsbhzoqO');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `course` varchar(255) DEFAULT NULL,
  `abstract` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `approval_status` enum('pending','approved','declined') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `author`, `title`, `course`, `abstract`, `file_path`, `approval_status`, `created_at`) VALUES
(1, 'Strike Acosta', 'RESEARCH MANAGEMENT SYSTEM', 'BSIT', 'DADASDASADFSDGDGVSVS', NULL, 'pending', '2024-04-05 11:55:03'),
(2, 'Gyles Blanco', 'File repository system', 'BSIT', 'asd', 'uploads/Untitled document (1).docx', 'pending', '2024-04-05 12:33:47'),
(3, 'Gyles Blanco', 'File repository system', 'BSIT', 'asd', 'uploads/Untitled document (1).docx', 'pending', '2024-04-05 12:42:40'),
(4, 'try', 'File repository system', 'BSIT', 'sd', 'uploads/Untitled document (1).docx', 'pending', '2024-04-05 12:43:14'),
(5, 'try', 'File repository system', 'BSIT', 'sd', 'uploads/Untitled document (1).docx', 'pending', '2024-04-05 12:45:42'),
(6, 'try', 'File repository system', 'BSIT', 'asd', '', 'pending', '2024-04-05 13:23:20'),
(7, 'try', 'File repository system', 'BSIT', 'asd', '', 'pending', '2024-04-05 13:29:00'),
(8, 'strike', 'MODULE 5', 'BSIT', 'das', 'uploads/Untitled document (1).docx', 'pending', '2024-04-10 14:40:05'),
(9, 'asd', 'asd', 'asd', 'asd', '', 'pending', '2024-04-10 15:11:27'),
(10, 'sad', 'asda', 'sdd', 'dsdsd', '', 'pending', '2024-04-10 15:28:34'),
(11, 'sd', 'sd', 'sd', 'sd', '', 'pending', '2024-04-14 13:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `superadmins`
--

CREATE TABLE `superadmins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `superadmins`
--

INSERT INTO `superadmins` (`id`, `username`, `password`) VALUES
(1, 'superadmin_username', 'hashed_password'),
(2, 'superadmin', '$2y$10$ICVQmhmnS5FoQWoozFBk5OmX1uSBvoY4BAZ9spf9zV3k5sLS6V4MO');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course` varchar(100) NOT NULL,
  `student_number` varchar(50) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('student','admin','super_admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `course`, `student_number`, `birthdate`, `address`, `contact_no`, `email`, `password`, `user_type`) VALUES
(1, 'STRIKE ACOSTA', 'BSIT', '21', '0000-00-00', 'NAIC', '212', 'strike@gmail.com', '123', ''),
(6, 'Strike Acosta', 'BSIT', '21', '0000-00-00', 'Naic', '123', 'strike@gmail.com', '123', ''),
(7, 'Strike Acosta', 'BSIT', '21', '0000-00-00', 'Naic', '123', 'strike@gmail.com', '123', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `superadmins`
--
ALTER TABLE `superadmins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `superadmins`
--
ALTER TABLE `superadmins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
